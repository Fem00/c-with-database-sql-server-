﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winform_loginn
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
           // this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            MessageBox.Show("Thank you ! for using our app V0.1 \n" +
                " PROJECT MADE  BY: \n1)Femi Bekele\n 2)Girum Alemayhe \n" +
                " 3)Ezana Lakew  ");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Products products = new Products();
            products.ShowDialog();
        }
    }
}
