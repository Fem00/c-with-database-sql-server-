﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace winform_loginn
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = this.textBox1.Text;
            String lastname = this.textBox3.Text;
            string password = this.textBox2.Text;
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("please enter name and password properly");
                return;
            }
            string connectionString = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=salonappdemo;Integrated Security=True;TrustServerCertificate=True";
            //  string sqlQuery = "SELECT COUNT(*) FROM Admin WHERE (FirstName + ' ' + LastName) = @Firstname AND Password = @Password";
            string sqlQuery = "SELECT COUNT(*) FROM Admin WHERE FirstName = @FirstName AND LastName = @LastName AND Password = @Password";
            ; using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    cmd.Parameters.AddWithValue("@Firstname", name);
                    cmd.Parameters.AddWithValue("@Lastname", lastname);
                    cmd.Parameters.AddWithValue("@password", password);
                    try
                    {
                        con.Open(); int userCount = (int)cmd.ExecuteScalar();
                        if (userCount > 0)
                        {
                            MessageBox.Show("Login successful");
                            this.Hide();
                            // Home home = new Home();
                            Homepage homepage = new Homepage();
                            homepage.ShowDialog();
                            // home.ShowDialog();
                            this.Close();

                        }
                        else
                        {
                            MessageBox.Show("Invalid name or password");
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                }
                this.Hide();
                // Home home = new Home();
                // Homepage homepage = new Homepage();
                // homepage.ShowDialog();
                // home.ShowDialog();
                this.Close();

                //Home home = new Home();
                //home.ShowDialog();
                //this.Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            form1.ShowDialog();
            this.Close();
        }
    }
}

