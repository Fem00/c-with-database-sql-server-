﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace winform_loginn
{
    public partial class Product_sales : Form
    {

        private SqlConnection connection;
        private string connectionstring = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=GPT;Integrated Security=True;Trust Server Certificate=True";
        public Product_sales()
        {
            InitializeComponent();
            connection = new SqlConnection(connectionstring);
            //LoadCategories();
            LoadProducts();
            SetupCartGrid();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void Product_sales_Load(object sender, EventArgs e)
        {

        }
        private void SetupCartGrid()
        {
            dataGridView2.Columns.Add("ProductID", "Product ID");
            dataGridView2.Columns.Add("Name", "Product Name");
            dataGridView2.Columns.Add("Price", "Price");
            dataGridView2.Columns.Add("Quantity", "Quantity");
            dataGridView2.Columns.Add("Subtotal", "Subtotal");
        }
        private void LoadProducts()
        {
            string query = "SELECT * FROM Products";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            int productId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ProductID"].Value);
            string productName = dataGridView1.SelectedRows[0].Cells["Name"].Value.ToString();
            decimal price = Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells["Price"].Value);
            int quantity = Convert.ToInt32(trackBar1.Value);
            decimal subtotal = price * quantity;

            dataGridView2.Rows.Add(productId, productName, price, quantity, subtotal);
            CalculateTotal();
        }
        //    private void button1_Click(object sender, EventArgs e)
        //    {
        //        int productId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ProductID"].Value);
        //        string productName = dataGridView1.SelectedRows[0].Cells["Name"].Value.ToString();
        //        decimal price = Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells["Price"].Value);
        //        int quantity = Convert.ToInt32(trackBar1.Value);
        //        decimal subtotal = price * quantity;

        //        dataGridView2.Rows.Add(productId, productName, price, quantity, subtotal);
        //        CalculateTotal();

        //    }
        //    private void CalculateTotal()
        //    {
        //        decimal total = 0;
        //        foreach (DataGridViewRow row in dataGridView2.Rows)
        //        {
        //            total += Convert.ToDecimal(row.Cells["Subtotal"].Value);
        //        }
        //        label5.Text = "Total: $" + total.ToString("F2");
        //    }
        //}
        //   private void button2_Click(object sender, EventArgs e)
        //    {
        //        try
        //        {
        //            // Define the file path
        //            string filePath = @"C:\Users\meked\Desktop\c# code\winform loginnt\receipt.txt";

        //            // Ensure the directory exists
        //            string directory = Path.GetDirectoryName(filePath);
        //            if (!Directory.Exists(directory))
        //            {
        //                Directory.CreateDirectory(directory);
        //            }

        //            // Create and write to the receipt file
        //            using (StreamWriter writer = new StreamWriter(filePath, true))
        //            {
        //                writer.WriteLine("Hair Salon Receipt");
        //                writer.WriteLine("----------------------");

        //                foreach (DataGridViewRow row in dataGridView2.Rows)
        //                {
        //                    // Check if the row has valid data before attempting to write
        //                    if (row.Cells["Name"].Value != null && row.Cells["Quantity"].Value != null && row.Cells["Subtotal"].Value != null)
        //                    {
        //                        writer.WriteLine($"{row.Cells["Name"].Value} x {row.Cells["Quantity"].Value} - ${row.Cells["Subtotal"].Value}");
        //                    }
        //                }

        //                writer.WriteLine("----------------------");
        //                writer.WriteLine($"Total: {label5.Text}");
        //            }

        //            // Message box to confirm receipt has been saved
        //            MessageBox.Show("Checkout completed! Receipt saved.");

        //            // Clear the DataGridView rows and recalculate total
        //            dataGridView2.Rows.Clear();
        //            CalculateTotal();
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show("Error: " + ex.Message);
        //        }

        //    }

        private void CalculateTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                total += Convert.ToDecimal(row.Cells["Subtotal"].Value);
            }
            label6.Text = "Total: $" + total.ToString("F2");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            try
            {
                // Define the file path
                string filePath = @"C:\Users\meked\Desktop\c# code\winform loginn\receipt.txt";

                // Ensure the directory exists
                string directory = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Create and write to the receipt file
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("Hair Salon Receipt");
                    writer.WriteLine("----------------------");

                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        // Check if the row has valid data before attempting to write
                        if (row.Cells["Name"].Value != null && row.Cells["Quantity"].Value != null && row.Cells["Subtotal"].Value != null)
                        {
                            writer.WriteLine($"{row.Cells["Name"].Value} x {row.Cells["Quantity"].Value} - ${row.Cells["Subtotal"].Value}");
                        }
                    }

                    writer.WriteLine("----------------------");
                    writer.WriteLine($"Total: {label6.Text}");
                }

                // Message box to confirm receipt has been saved
                MessageBox.Show("Checkout completed! Receipt saved.");

                // Clear the DataGridView rows and recalculate total
                dataGridView2.Rows.Clear();
                CalculateTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Homepage homepage = new Homepage();
            homepage.ShowDialog();
            this.Close();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            add_products_cs add_Products_Cs = new add_products_cs();
            add_Products_Cs.ShowDialog();
            this.Hide();
        }
    }
}
