﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace winform_loginn
{
    public partial class add_products_cs : Form
    {

        private SqlConnection connection;
        private string connectionstring = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=GPT;Integrated Security=True;Trust Server Certificate=True";
        public add_products_cs()
        {
            InitializeComponent();
            connection = new SqlConnection(connectionstring);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            LoadCategories();
            LoadProducts();
        }

        private void add_products_cs_Load(object sender, EventArgs e)
        {

        }
        private void LoadCategories()
        {
            string query = "SELECT ProductID, CategoryID, Price, StockQuantity FROM Products";


            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // comboBox1.DisplayMember = "Name";
                // comboBox1.ValueMember = "CategoryID";
                // comboBox1.DataSource = dt;
            }
        }
        private void LoadProducts()
        {
            string query = "SELECT ProductID, Name, CategoryID, Price, StockQuantity FROM Products";

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
             int categoryID = (int)comboBox1.SelectedValue;
            decimal price = Convert.ToDecimal(textBox2.Text);
            int stockQuantity = Convert.ToInt32(textBox3.Text);

            string query = "INSERT INTO Products (Name, CategoryID, Price, StockQuantity) " +
                           "VALUES (@Name, @CategoryID, @Price, @StockQuantity)";

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@CategoryID", categoryID);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@StockQuantity", stockQuantity);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product added successfully!");
                    LoadProducts(); // Refresh the products list
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private void ClearFields()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            //comboBox1.SelectedIndex = -1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int productID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value); // Get selected product ID

                string query = "DELETE FROM Products WHERE ProductID = @ProductID";

                using (SqlConnection conn = new SqlConnection(connectionstring))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ProductID", productID);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product deleted successfully!");
                        LoadProducts(); // Refresh the products list
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a product to delete.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Name"].Value.ToString();
                // cmbCategoryID.SelectedValue = row.Cells["CategoryID"].Value;
                textBox2.Text = row.Cells["Price"].Value.ToString();
                textBox3.Text = row.Cells["StockQuantity"].Value.ToString();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Homepage homepage = new Homepage();
            homepage.ShowDialog();
            this.Hide();

        }
    }
}
