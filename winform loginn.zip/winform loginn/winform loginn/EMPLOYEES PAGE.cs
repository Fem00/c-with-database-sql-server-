﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace winform_loginn
{
    public partial class EMPLOYEES_PAGE : Form
    {
        private string constring = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=salonappdemo;Integrated Security=True;Trust Server Certificate=True ";
        public EMPLOYEES_PAGE()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void EMPLOYEES_PAGE_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Homepage homepage = new Homepage();
            homepage.ShowDialog();
            this.Close();
        }

        private void BindData()
        {
            using (SqlConnection conn = new SqlConnection(constring))
            {
                conn.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM EMP ", conn);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO EMP (Name, Gender ,Role,Salary,Phone ) VALUES (@name, @gender, @role,@salary,@phone)", con);
                command.Parameters.AddWithValue("@name", textBox1.Text);
                command.Parameters.AddWithValue("@gender", comboBox2.SelectedItem.ToString());
                command.Parameters.AddWithValue("@role", comboBox1.SelectedItem.ToString());
                command.Parameters.AddWithValue("@salary", textBox4.Text);
                command.Parameters.AddWithValue("@phone", textBox5.Text);
                command.ExecuteNonQuery();
                BindData();
                string message = $"Employe{textBox1.Text} hired  for  role {comboBox1.SelectedItem} from " +
                    $"{DateTime.Now} with salary of {textBox4.Text}";
                MessageBox.Show(message);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            BindData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string connectionString = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=salonappdemo;Integrated Security=True;Trust Server Certificate=True ";

                // Get the name of the selected customer (assuming the Name column is the second column)
                //  int customerId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                string customerName = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("DELETE FROM EMP WHERE Name = @Name", connection);
                    command.Parameters.AddWithValue("@Name", textBox1.Text);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show($"Employee '{textBox1.Text}' Fired from this day on:{DateTime.Now}.");
                    }
                    else
                    {
                        MessageBox.Show("No matching employee found.");
                    }

                    // Update DataGridView
                    BindData();
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string searchitem = textBox2.Text.Trim();
            if (string.IsNullOrEmpty(searchitem))
            {
                MessageBox.Show("please enter a name to search");
                return;
            }
            using (SqlConnection connection = new SqlConnection(constring)) {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM EMP WHERE Name LIKE @search", connection);
                cmd.Parameters.AddWithValue("@search", "%" + searchitem + "%");
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Assuming you have a DataGridView to display the search results
                dataGridView1.DataSource = dataTable;
           

            }
                
        }
    }
}
