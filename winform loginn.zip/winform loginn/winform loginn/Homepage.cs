﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winform_loginn
{
    public partial class Homepage : Form
    {
        public Homepage()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void Homepage_Load(object sender, EventArgs e)
        {

        }

        private void CUSTOMERS_Click(object sender, EventArgs e)
        {
           CUSTOMERS cUSTOMERS = new CUSTOMERS();
            cUSTOMERS.ShowDialog();
            this.Close();
        }

        private void EMPLOYEES_Click(object sender, EventArgs e)
        {
            EMPLOYEES_PAGE eMPLOYEES_ = new EMPLOYEES_PAGE();
            eMPLOYEES_.ShowDialog();
            this.Close();

        }

        private void STASTICS_Click(object sender, EventArgs e)
        {
            STASTICScs sTASTICScs = new STASTICScs();
            sTASTICScs.ShowDialog();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
           
            Product_sales product_Sales = new Product_sales();
            product_Sales.ShowDialog();
            this.Hide();
        }
    }
}
