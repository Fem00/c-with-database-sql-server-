﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace winform_loginn
{
    public partial class CUSTOMERS : Form
    {
        public CUSTOMERS()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }
        private string constring = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=salonappdemo;Integrated Security=True;Trust Server Certificate=True";


        private void CUSTOMERS_Load(object sender, EventArgs e)
        {

        }
        private void BindData()
        {
            using (SqlConnection conn = new SqlConnection(constring))
            {
                conn.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM CustomersT ", conn);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
            string.IsNullOrWhiteSpace(textBox2.Text) ||
            comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Please fill required  fields.");
                return;
            }

            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO CustomersT (Cname, PHONE,SERVICE,TIME ) VALUES (@Name, @Phone, @service,@time)", con);
                command.Parameters.AddWithValue("@Name", textBox1.Text);
                command.Parameters.AddWithValue("@Phone", textBox2.Text);
                command.Parameters.AddWithValue("@service", comboBox1.SelectedItem.ToString());
                command.Parameters.AddWithValue("@time", dateTimePicker1.Value);
                command.ExecuteNonQuery();
                BindData();
                string message = $"customer {textBox1.Text} scheduled for {DateTime.Now}";
                MessageBox.Show(message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BindData();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            Homepage homepage = new Homepage();
            homepage.ShowDialog();
            this.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Enter a customer name to remove from list ");
                return;
            }

            using (SqlConnection connection = new SqlConnection(constring))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("DELETE FROM CustomersT WHERE Cname = @Name", connection);
                    command.Parameters.AddWithValue("@Name", textBox1.Text);
                    int rowsaffected = command.ExecuteNonQuery();
                    if (rowsaffected > 0)
                    {
                        MessageBox.Show($"customer {textBox1.Text} deleted succesfully");
                        BindData();
                    }
                    else
                    {
                        MessageBox.Show("customer not found");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string searchTerm = textBox3.Text.Trim();
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Please enter a name or phone number to search.");
                return;
            }
            using (SqlConnection connection = new SqlConnection(constring)) {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM CustomersT WHERE Cname LIKE @search OR PHONE LIKE @search", connection);
                command.Parameters.AddWithValue("@search", "%" + searchTerm + "%");

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Assuming you have a DataGridView to display the search results
                dataGridView1.DataSource = dataTable;

              
            }
           
        }
    }
}

