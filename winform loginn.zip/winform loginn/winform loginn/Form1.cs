using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.Data.SqlClient;

namespace winform_loginn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            this.Hide();
            Form2 form2 = new Form2();
            form2.ShowDialog();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string firstname = textBox1.Text;
            string lastname = textBox2.Text;
            string passeord = textBox3.Text;
            string cpassword = textBox4.Text;

            if (string.IsNullOrWhiteSpace(firstname) || string.IsNullOrWhiteSpace(lastname) ||
                string.IsNullOrWhiteSpace(passeord) || string.IsNullOrWhiteSpace(cpassword))
            {
                MessageBox.Show("All fields are required");
                return;
            }
            if (passeord != cpassword)
            {
                MessageBox.Show("Passwords do not match");
                return;
            }
            string connectionString = "Data Source=FEMO\\SQLEXPRESS;Initial Catalog=salonappdemo;Integrated Security=True;TrustServerCertificate=True";
            //  string sqlQuery = "SELECT COUNT(*) FROM Users WHERE (FirstName + ' ' + LastName) = @Firstname AND Password = @Password";
            string sqlQuery = "INSERT INTO Admin (FirstName, LastName, Password) VALUES (@FirstName, @LastName, @Password)";

            // using (SqlConnection con = new SqlConnection(connectionString) { }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@FirstName", firstname);
                    cmd.Parameters.AddWithValue("@LastName", lastname);
                    cmd.Parameters.AddWithValue("@Password", passeord);
                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Registration successful");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                //MessageBox.Show("registration successful");
                //Home home = new Home();
                Form2 form2 = new Form2();
                form2.ShowDialog();
                this.Close();
                //home.ShowDialog();
                //Form1 form1 = new Form1();
                //form1.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
